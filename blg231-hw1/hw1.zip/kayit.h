/* @Author
* Student Name: TURGUT CAN AYDINALEV
* Student ID : 150120021
* Date: 12.10.2016
*/
struct patient_record {

	char name[20], doctorName[20], diagnosis[30];
	int patientNumber, polyclinicNumber;
	char branchName[20];
};